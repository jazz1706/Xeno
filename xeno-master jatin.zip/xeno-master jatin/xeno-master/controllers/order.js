const Consumer = require("../models/consumer");
const Order =require("../models/order");




exports.createOrder = async (req, res) => {
    const { consumer_id,fname, lname,  orderPrice } = req.body;

    if (!fname || !lname  || !email ||!orderPrice) {
        return res.status(400).json({
            success: false,
            message: "Enter all the details carefully"
        });
    }

    try {
       


        const existingOrderCount = await Order.countDocuments();
        const order_id = existingOrderCount + 1;

      
        const newOrder = await Order.create({consumer_id,order_id, fname, lname, orderPrice });

       
        res.status(200).json({
            success: true,
            data: { newOrder},
            message: "User created successfully"
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            data: "Internal server error",
            message: "Error in creating user"
        });
    }
};

/*
Import the Models: Load the Consumer and Order models to interact with the consumer and order data in the database.
Define createOrder Function: Create an asynchronous function to handle the creation of a new order.
Extract Data: Get consumer_id, fname, lname, and orderPrice from the request body.
Validate Input: Check if any required fields are missing and respond with an error if they are.
Count Existing Orders: Determine the current number of orders in the database to assign a new ID.
Create New Order: Create a new order with the provided data.
Send Success Response: If successful, send a response with the new order data.
Handle Errors: Catch and log any errors, then send an error response.
*/